<?php $__env->startSection('title','Saved Properties'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <h4>Saved Propeties list </h4>
        <small><strong> Remaining Properties that can be saved <?php echo e($Rcout); ?> and <?php echo e($timeExceed); ?> </strong></small>
        <ul class="list-group" style="padding-top:10px ">
    <?php $__currentLoopData = $propertiesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item list-group-item-action savedPropertiesList ">
                    <div class="d-flex w-100 justify-content-between">
                        <a href="/getOwnerDetail/<?php echo e($item->line1); ?>/<?php echo e($item->line2); ?>" class="savedPropertyitem"> <?php echo e(utf8_decode(urldecode($item->line1))); ?> <?php echo e(utf8_decode(urldecode($item->line2))); ?> </a>
                        <a href="/deletesaveproperty/<?php echo e($item->id); ?>" class="btn btn-primary">Delete</a>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('.nav-link').removeClass("active");
        $("#menu5").addClass("active");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>