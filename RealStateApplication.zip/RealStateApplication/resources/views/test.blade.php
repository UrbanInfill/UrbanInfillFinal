@extends('master')
@section('title','MyPage Title')
@section('content')


@endsection