<?php


namespace App;

use Illuminate\Database\Eloquent\Model;

class Mailertemplate extends Model
{
    protected $table = 'mailertemplate';
}